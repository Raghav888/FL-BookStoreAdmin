import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getTableData, postNewData } from "./httpclients";

export const useTableData = () =>
  useQuery({
    queryKey: ["getTableData"],
    queryFn: () => getTableData(),
    refetchInterval:false,
    staleTime: 100000000,
  });

export const useAddData = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: postNewData,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["getTableData"] });
    },
  });
};