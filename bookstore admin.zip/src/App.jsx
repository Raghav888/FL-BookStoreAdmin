import { useState } from "react";
import DataTable from "./components/DataTable";
import SearchAppBar from "./components/SearchAppBar";
import { useTableData } from "./httpClients/queries";

function App() {
  const [searchInput, setSearchInput] = useState();
  const { data } = useTableData();
  
  const updateSearch = (newString) => setSearchInput(newString);

  const filteredData = () => {
    if (!searchInput) {
      return data;
    }
    const newData = data.filter((obj) => obj.name.toLowerCase().includes(searchInput.toLowerCase()));
    return newData;
  };

  return (
    <>
      <SearchAppBar updateSearch={updateSearch} />
      <div className="dataTable">
        <DataTable tableData={filteredData()} />
      </div>
    </>
  );
}

export default App;
