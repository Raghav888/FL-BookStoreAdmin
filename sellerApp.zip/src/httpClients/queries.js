import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getTableData, updateQuantity } from "./httpclients";

export const useTableData = () =>
  useQuery({
    queryKey: ["getTableData"],
    queryFn: () => getTableData(),
    refetchInterval:false,
    staleTime: 10000,
  });

export const useUpdateData = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: updateQuantity,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["getTableData"] });
    },
  });
};
