import axios from "axios";

export const getTableData = async () => {
  const response = await axios.get(
    "http://sku-warehouse-3.us-east-1.elasticbeanstalk.com/items"
  );
  return response?.data?.data;
};

export const updateQuantity = async (payload) => {
  await axios.put(
    `http://sku-warehouse-3.us-east-1.elasticbeanstalk.com/item/${payload.id}`,
    { name: payload.name, quantity: payload.quantity }
  );
};
